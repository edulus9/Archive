using namespace std;

// versione 10.0 per codeblocks 16 -  minggw 32 bit

#ifndef EASY_C9_H
#define EASY_C9_H

#include <math.h>
#include <iostream>
#include <sstream>
#include <string.h>
#include <stdlib.h>
//=======================================================

#ifndef random
#define random(range) (rand() % (range))
#endif

int KeyCode();
/** aspetta che l'utente prema un tasto restituendo il codice interno.
    Se gli 8 bit piu' significativi sono uguali a zero, allora gli 8 bit
    meno significativi rappresentano il carattere premuto sulla tastiera;
    altrimenti keyCode restituisce il codice esteso del tasto negli 8 bit
    piu' significativi come indicato nei #define KEY_?? che seguono.
    Funziona in modalita' testo
*/

#define KEY_HOME       71
#define KEY_UP         72
#define KEY_PGUP       73
#define KEY_LEFT       75
#define KEY_CENTER     76
#define KEY_RIGHT      77
#define KEY_END        79
#define KEY_DOWN       80
#define KEY_PGDN       81
#define KEY_INSERT     82
#define KEY_DELETE     83
#define KEY_F1		   59
#define KEY_F2         60
#define KEY_F3         61
#define KEY_F4		   62
#define KEY_F5		   63
#define KEY_F6			64
#define KEY_F7			65
#define KEY_F8			66
#define KEY_F9			67


//-----------------------------------------------------------------------------
int Getch();
int Kbhit();

void WaitESC();
/// Aspetta che l'utente prema <ESC>

void WaitESC( const string & S);
/// Aspetta che l'utente prema <ESC>, ma. a differenza del precedente
/// scrive nell' angolo basso a destra il contenuto del parametro.
/// Serve per controlli di Debug.

void Beep(int F=400);

void delay( int msec );

#define Mostrati Show
#define  Nasconditi Hide

#define AND &&
#define OR  ||
#define NOT !
#define BEGIN {
#define END   }
#define InizioProgramma    int main() {
#define FineProgramma      return 0; }
#define PerSempre          for(;;)
#define Loop          for(;;)

#define PerIndirizzo   &
#define PerReferenza   &

#define PiGreco    M_PI

class ColoreRGB
{  public:
      ColoreRGB( int r, int g, int b);
      ColoreRGB( int c =-1);
      static ColoreRGB Random();
      ColoreRGB operator ++ (int); /// schiarisce il colore
      ColoreRGB operator -- (int); /// scurisce il colore
      ColoreRGB operator ++ ();    /// schiarisce il colore
      ColoreRGB operator -- ();    /// scurisce il colore
      ColoreRGB operator - ();    /// colore complementare
      ColoreRGB operator + (const ColoreRGB &);    /// somma di colori
      ColoreRGB operator - (const ColoreRGB &);    /// differenza di colori

      operator int();
  	  friend ostream & operator << (ostream & s, const ColoreRGB & c);
 private:
      int R,G,B;
};///ColoreRGB


extern ColoreRGB
Trasparente,
Nero, GrigioScuro, Grigio,GrigioChiaro,  Bianco,
BluScuro,  Blu,   Azzurro,  BluChiaro, Cyan, Celeste,
Verde,  VerdeChiaro,
Rosa, Arancio, Rosso,  RossoChiaro, Magenta, Violetto,
Marrone, Giallo,
Salmone,  Argento;



//---------------------------------
class SetCaratteri
{ public:
   	SetCaratteri( );       /// Set vuoto
   	SetCaratteri(char *); /// inizializzazione con un insieme di caratteri

   	SetCaratteri operator + ( const SetCaratteri & ) const;    /// unione
        #define Set_Unione +
   	SetCaratteri operator * ( const SetCaratteri & ) const;    /// intersezione
        #define Set_Intersezione *
   	SetCaratteri operator - ( const SetCaratteri & ) const;    /// differenza
        #define Set_Differenza -
   	SetCaratteri operator ! ( ) const;    /// complemento
        #define Set_Complemento !
	void operator += ( char ); /// aggiunta di un elemento
   	void operator += ( char* ); /// aggiunta di una sequenza di caratteri

   	friend bool operator <= ( char, const SetCaratteri & ); /// appartenenza
        #define Set_IN <=
   	bool operator <= ( const SetCaratteri & ) const; /// inclusione in senso largo
   	bool operator < ( const SetCaratteri & ) const; /// inclusione in senso stretto
  	bool operator == ( const SetCaratteri & SetB ) const;

   	friend ostream & operator << (ostream &, const SetCaratteri & );
    friend string & operator << (string &, const SetCaratteri & );

private:

	bool Vett[128];   /// 128 e` la cardinalita` massima dell'insieme
	/// vettore che indica la presenza (True) o l'assenza (False) dell'elemento dell'insieme
	void CreaInsiemeVuoto( ); /// funzione di comodo

}; /*class SetCaratteri*/


//===========================================================================

class Cronometro
{ public:
     Cronometro( );
     void Start();
     void Stop();
     void Reset();
     float Tempo() const;  /// valore segnato dal cronometro
     float Time() const { return Tempo();};  /// valore segnato dal cronometro

  private:
     float Ti;    /// Tempo iniziale: misura assoluta
     float TempoAccumulato; ///
     bool StatoConteggio;
}; /* Cronometro */


//-----------------------------------------------------------------------------
class Grafica
{  public:
    Grafica(int l, int h);
    ~Grafica();
   static float Larghezza();
   static float Altezza();
   static float CentroX();
   static float CentroY();
   static float ScalaY();
   static float ScalaX(); /// fattori X Y di zoom

   static void FinestraVisibile( float Xi, float Ys, float Xs, float Yi );
   static void SetLimits( float Xi, float Ys, float Xs, float Yi )
   { FinestraVisibile(  Xi,  Ys,  Xs,  Yi );}
   /// Lo spazio video vieme imposto dalla finestra che guarda al
   /// piano cartesiano.
   /// Gli estremi degli assi cartesiani vengono imposti nel seguente modo:
   /// Asse X:  Xi ------> Xs        Asse Y: Yi--------> Ys
   /// Angolo sinistro alto Xi,Ys - angolo destro basso Xs,Yi
   /// Il rapporto Altezza/Larghezza della finestra dovrebbe essere 3/4
   /// altrimenti la scala delle ascisse risulta essere diversa
   /// dalla scala delle ordinate.
   /// Per default il piano della Tartarga viene impostato con lo zero
   /// al centro: Grafica::FinestraVisibile(-319, +240, +320, -239);
   /// Si possono orientare opportunamente gli assi.
   /// Per far coincidere le coordinate tartarga con le coordinate pixel
   /// dello schermo: Grafica::FinestraVisibile(0,0, 639, 479);


   protected:
   static int IstanzeGrafiche;    /// contatore di istanze
   static void InitGraphComune(int l, int h);
   static void ResetDimension();
   static float
   Larghezz, Altezz, /// dello schermo RealPixels
   CentrX, CentrY,   /// posiz. centro assi cart. piano reale  della T,
		  /// rif. al piano RealePixels
   ScalY,ScalX;     /// fattore zoom
   static ColoreRGB ColorBK;
};

class VettoreInt; class VettoreFloat; class MatriceInt; class MatriceFloat;

//------------------------- dichiarazioni per include TARTA.H
class Espressione;
class Sprite;

class Tartaruga: Grafica
{  public:

   Tartaruga(int l=800, int h=600);
   Tartaruga( const Tartaruga & ); /// copy costructor
   ~Tartaruga();

   void Tana(); /// RIPORTA LA TARTARUGA NELLA POSIZIONE 0,0
   void Home(){Tana(); }

   void ClearScreen(ColoreRGB c=Trasparente );   /// PULISCE LO SCHERMO UTILIZZANDO IL COLORE c
   void PulisciSchermo(ColoreRGB c=Trasparente ) { ClearScreen(c); }

   void TempoPasso(int);
   void Time(int A){ TempoPasso(A); }

   void Velocita(int);
   void Speed(int A){ Velocita(A); }

   void Avanti( float );
   void VaiAvanti( float X ){ Avanti(X); }
   void A(float X){ Avanti(X); }

   void Indietro( float );
   void VaiIndietro( float X){ Avanti(-X);}
   void I(float X) { Avanti(-X);}

   void GiraDestra( float );
   #define Destra GiraDestra
   void D(float A){ GiraDestra(A);}

   void GiraSinistra( float );
   #define   Sinistra  GiraSinistra
   void S(float A) { GiraDestra(-A); }

   void Su();
   void AlzaPennello(){ Su();}
   void Up(){ Su();}

   void Giu();
   void AbbassaPennello(){ Giu();}
   void Down(){ Giu();}

   void Color( ColoreRGB  C);
   #define Colore Color
   void CambiaColorePennello( ColoreRGB  C) { Color(C);};
   ColoreRGB ColorePennello() const;
   ColoreRGB ColoreFondo() const;
   ColoreRGB ColoreSottoLaCoda() const;

   void UsaPennelloLargo();
   void UsaPennelloSottile();

   void DoveSei( float & Xo, float & Yo ) const;
   float X() const;
   float Y() const;

   void MettiUnPunto( float Xo, float Yo );  /// METTI UN PUNTO IN Xo Yo
   void MettiUnPunto( float X, float Y, ColoreRGB Colore );
   #define PointXY  MettiUnPunto
   #define FastPointXY MettiUnPunto

   void Vai( float x, float y );
   void GoToXY( float x, float y ) { Vai(x,y);};
   void Salta(float X, float Y );
   void Jump( float x, float y ) { Salta(x,y);};

   void SpostatiDi( float DX, float DY);

   float MaxX() const;
   float MaxY() const;
   float MinX() const;
   float MinY() const;

   bool FuoriSchermo() const;

   float Direzione() const;
   void Direzione( float A );
   void DirezioneAlPunto( float Xo, float Yo );
   #define GiraVerso DirezioneAlPunto
   #define SetDirectionToPoint DirezioneAlPunto


   void RiempiColore(ColoreRGB ColoreRiemp, ColoreRGB ColoreBordo );
   /// LA TARTARUGA COLORA LA FIGURA GEOMETRICA  CHE LA RACCHIUDE
   ///  UTILIZZANDO "coloreRiemp" ( LA FIGURA E` DISEGNATA CON "coloreBordo" )
   void RiempiColore( );
   /// La tartaruga "tenta" di colorare la figura chiusa che ha appena
   /// disegnato, usando come colore di riempimento quello della figura.
   /// Se la figura non e` chiusa gli effetti sono imprevedibili
   #define Fill     RiempiColore


   void Mostrati();

   void Nasconditi();
   void Cerchio(double R);
   void Griglia(ColoreRGB ColoreAssi=Verde, ColoreRGB ColoreGriglia=Verde);

   void GraficoFunzione( double (*F)(double), ColoreRGB ColoreGrafico=Bianco,
                         ColoreRGB ColoreAssi=Trasparente,
                         ColoreRGB ColoreGriglia=Trasparente);

   void GraficoFunzione( Espressione E, ColoreRGB ColoreGrafico=Bianco,
                         ColoreRGB ColoreAssi=Trasparente,
                         ColoreRGB ColoreGriglia=Trasparente );
   #define PlotFunction GraficoFunzione
   ///  esempi di chiamata:
   ///  T.GraficoFunzione( sin, rosso );
   ///  T.GraficoFunzione( FuncMia, 3 );  /// "FuncMia" funz. definita dall'utente
   ///  T.GraficoFunzione( "12*X*X+123" );


   int Interpreta(char * Comandi );
   /// interpreta la stringa Comandi del tipo : " A(100) Destra 90 indietro12.3 "
   /// In caso di errore restituisce la posizione del carattere che ha causato
   /// errore, altrimenti restituisce 0
   ///I comandi riconosciuti sono:   "su", "up", "giu", "down",
   /// "a","i","d","s", "avanti", "indietro", "destra", "sinistra",
   /// "color","colore","clear", "pulisci",
   /// "gotoxy","vai", "tana","home","mostra","show","nascondi","hide",
   /// "riempicolore" "fill"

   Tartaruga & operator << ( const string S );
   Tartaruga & operator << ( const VettoreInt & );
   Tartaruga & operator << ( const VettoreFloat & );
   Tartaruga & operator << ( const MatriceInt & );
   Tartaruga & operator << ( const MatriceFloat &  );
   Tartaruga & operator << ( const char *S );
   Tartaruga & operator << ( const int N );
   Tartaruga & operator << ( const char C );
   Tartaruga & operator << ( const double D );
   /// Invia un dato numerico alla finestra
   /// Non esistono, per il momento, modificatori di formato.


//***************************** LETTURE **********************************

   Tartaruga & operator >> ( double & D );
   Tartaruga & operator >> ( float & D );
   Tartaruga & operator >> ( long & I );
   Tartaruga & operator >> ( int & I );
   Tartaruga & operator >> ( char & C );
   Tartaruga & operator >> ( string & S );
   Tartaruga & operator >> ( Espressione & S );
   Tartaruga & LeggiStringa( char * S, unsigned int L );

/// L'oggetto "Tartaruga" legge da tastiera riportando il contenuto
/// sia sullo schermo sia nel parametro (lettura con eco).
/// Sono a disposizione alcuni comandi per l'editing sulla linea di immissione:
///  <backspace>, <Del>,  le freccie <Dx>, <Sx>  e il tasto  <Ins>.
/// Se si preme il tasto <ESC>, la Tartaruga termina la lettura e restituisce
/// 0 nel caso di parametro numerico non inserito oppure la stringa originale.
/// Utilizzando il comando LeggiStringa e` necessario assicurarsi che esista
/// lo spazio sufficiente a contenere la stringa: il numero L di caratteri che
/// al massimo si puo` immettere in S comprende anche '\0' che viene inserito
/// quando si preme il tasto <ENTER>.


Tartaruga & operator << ( Tartaruga & (* F)( Tartaruga & ) );


void CaricaImmagine(char * NomeImmagine, double X, double Y);

//------------------------------------------------------------------------------
private:

int   ID,        /// identificativo dell'istanza
      RitardoT,
      Copia;

ColoreRGB ColoreT;

int  PenGiu, PennelloLargo, FontGrande; ///bool

float
      UA, AngoloT,       /// direzione tartaruga in radianti:
		                 /// antiorario,verticale 90 = Pigreco /2
      RealX,         /// ** POSIZIONE TARTARUGA piano reale-pixels
      RealY;         /// ** alto sinistra 0, 0  riferito al piano RealPixels

void TartaZero();
void DisegnaTarta_g();
void CancellaTarta_g();
void RitardaResetCancella();
void FormaTarta(float);
void Leggi( string & S );
Tartaruga & Scrivi( const char *S );

//friend
//class Sprite;

Sprite * pFig;

// char * idF; /// nome del file sorgente su cui si sta` lavorando
// int idL;/// linea del file sorgente dove l'oggetto e` dichiarato
}; // Tartaruga_.h -----------------------------------------------------------



///=================== MANIPOLATORI ========================================

Tartaruga & endl( Tartaruga & );



//------------------------------------------------------
class VettoreInt
{
public:

       VettoreInt(); ///

       VettoreInt( const VettoreInt  &  ); ///   VettoreInt X = Y;  /// Copy Constructor

       ~VettoreInt();  ///

       VettoreInt  & operator= ( const VettoreInt  & );   /// assegnamento

       const int operator[] (unsigned int) const; // osservazione:  R_op
       int & operator[] (unsigned int);  // modifica: L_op

       void Dimensione( unsigned int NuovaDim ); /// impone la dimensione al vettore
       // resize // reserve
       unsigned int Dimensione() const; /// interroga sulla dimensione del vettore
       // size
       friend ostream & operator << ( ostream & S, const VettoreInt & V );
       friend istream & operator >> ( istream & S, VettoreInt & V );

protected:
       // int ID;  static cntID;
       int *pV;           /// puntatore alla struttura vettore di int
       unsigned int DimensioneAttuale;      /// dimensione attuale del vettore
       void init( const int *, unsigned int );

//char * idF; /// nome del file sorgente su cui si sta` lavorando
//int idL;/// linea del file sorgente dove l'oggetto e` dichiarato
};/* VettoreInt  */


class MatriceInt
{
public:

       MatriceInt(); ///
       MatriceInt( const MatriceInt  &  );    ///   MatriceInt X = Y;  /// Copy Constructor
       ~MatriceInt();  ///

       MatriceInt & operator= ( const MatriceInt  & );   /// assegnamento
       VettoreInt & operator[ ] ( unsigned int i );
       VettoreInt operator[ ] ( unsigned int i ) const;

       void Dimensioni( unsigned int DimR, unsigned int DimC );
       /// impone le dimensioni alla Matrice
       unsigned int NumeroRighe() const;
       unsigned int NumeroColonne() const;
       void NumeroRighe(unsigned int);
       void NumeroColonne(unsigned int);

       friend ostream & operator << ( ostream & S, const MatriceInt  & V );
       friend istream & operator >> ( istream & S, MatriceInt & V );

protected:
       VettoreInt *pV;           /// puntatore alla struttura vettore di int
       unsigned int Rig, Col;

//char * idF; /// nome del file sorgente su cui si sta` lavorando
//int idL;/// linea del file sorgente dove l'oggetto e` dichiarato

};/* MatriceInt  */



class VettoreFloat
{
public:

       VettoreFloat(); ///

       VettoreFloat( const VettoreFloat  & );    ///   VettoreFloat X = Y;  /// Copy Constructor

       ~VettoreFloat();  ///

       VettoreFloat  & operator= ( const VettoreFloat  & );   /// assegnamento

       float & operator[] (unsigned int);
       const float operator[] (unsigned int) const;

       void Dimensione( unsigned int NuovaDim ); /// impone la dimensione al vettore
       unsigned int Dimensione() const; /// interroga sulla dimensione del vettore

       friend ostream & operator << ( ostream & S, const VettoreFloat  & V );
       friend istream & operator >> ( istream & S, VettoreFloat & V );


protected:
       /// int ID;  static cntID;
       float *pV;           /// puntatore alla struttura vettore di int
       unsigned int DimensioneAttuale;      /// dimensione attuale del vettore
       void init( const float *, unsigned int );
//char * idF; /// nome del file sorgente su cui si sta` lavorando
//int idL;/// linea del file sorgente dove l'oggetto e` dichiarato

};/* VettoreFloat  */


class MatriceFloat
{
public:

       MatriceFloat(); ///

       MatriceFloat( const MatriceFloat  & );    ///   MatriceFloat X = Y;  /// Copy Constructor

       ~MatriceFloat();  ///

       MatriceFloat  & operator= ( const MatriceFloat  & );   /// assegnamento

       VettoreFloat & operator[] ( unsigned int i );
       VettoreFloat operator[] ( unsigned int i ) const;

       void Dimensioni( unsigned int DimR, unsigned int DimC );
       /// impone le dimensioni alla Matrice
       unsigned int NumeroRighe() const;
       unsigned int NumeroColonne() const;
        void NumeroRighe(unsigned int);
       void NumeroColonne(unsigned int);

       friend ostream & operator << ( ostream & S, const MatriceFloat  & V );
       friend istream & operator >> ( istream & S, MatriceFloat & V );

protected:

       VettoreFloat *pV;           /// puntatore alla struttura vettore di int
       unsigned int Rig, Col;
 };/* MatriceFloat  */

//=====================================================================
class Icona: protected Grafica
  { public:
       Icona(); /// costruttore di default (per esempio per dichiarare
                /// un vettore di icone anonime --> Icona VI[N];
       Icona( char * ); /// l'Icona e` timida: quando nasce e` nascosta
       Icona( const Icona & );
       ~Icona();
       Icona & operator = (Icona & );
       void DisegnatiIn(int Xo, int Yo, int rotazione=0);
       ///disegna una icona in pos. Xo,Yo, ruotandola un multiplo di 90 gradi

   private:
       int * px;
       int xo,yo;
  };


#ifndef ALBERO_BIN
#define ALBERO_BIN

class AlberoBin0 //------------------------------------------------------------
{
public:

     AlberoBin0(); // Costruttore di defaul

     AlberoBin0( const AlberoBin0 & A);
     // Copy constructor ( inizializzatore )

     AlberoBin0( const char dato, const AlberoBin0 & S,const AlberoBin0 & D );
     // Costruttore

     ~AlberoBin0();   // Distruttore:  elimina l'istanza di albero:

     AlberoBin0 LSubTree( ) const;  // Restituisce l'albero sinistro

     AlberoBin0 RSubTree( ) const;  // Restituisce l'albero destro

      char Root( ) const;    // Restituisce l'informazione della radice

     AlberoBin0 & operator = ( const AlberoBin0 & A );  // ASSEGNAZIONE

     int operator == ( const AlberoBin0 & A ) const;
     // UGUAGLIANZA per forma e contenuto

     int NumNodi( ) const; // numero dei nodi che compongono l'albero

     int Vuoto() const; // se l'albero e` vuoto


     int PresenteInfo( const  char  ) const;
     // se una informazione e` presente nell'albero

protected:

     struct Nodo
     { Nodo( const char , Nodo * L = 0, Nodo * R = 0);
        char Info;
       Nodo  *Ltree, *Rtree;
     } * pRadice;     // puntatore alla struttura albero in heap

     //----------------------------- procedure e funzioni ad uso interno

     int AlberiUguali( Nodo *, Nodo * ) const;
     // stessa forma, stesse informazioni

     int Foglia( Nodo *) const; // se l'albero e` foglia

     void DeleteTree( Nodo * );

     Nodo * CopyTree( Nodo * ) const;

     int NumNodiR( Nodo * ) const;

     int PresenteInfoR( const  char , Nodo *  ) const;

}; // fine classe AlberoBin0   ------------------------------------------------

#endif

#ifndef ESPRESS_CLASS
#define ESPRESS_CLASS

class Espressione: public AlberoBin0
{
 public:
        Espressione( );  /// espressione vuota
        ~Espressione( );  ///

        Espressione( string ); /// inizializzata con una stringa
        Espressione( const char * pE );/// inizializzata con una stringa-C
        Espressione( const Espressione & ); /// copy costructor
         //---------------------------------------------------
        Espressione & operator = ( const char * pE );
        Espressione & operator = ( const Espressione & );

        /// assegnamento tra stringhe-espressioni
        /// ~Espressione( ); viene utilizzato il distruttore della Classe Base

        double operator() ();
	    /// calcola il valore di una espressione aritmetica

        double operator() ( double X );
        /// calcola il valore di una funzione in X,  per un valore di X

        Espressione Derivata();
        friend Espressione D(Espressione);

         ///
        static const char * FunzioniRiconosciute(); /// elenca le funzioni riconoscite

        friend ostream & operator << ( ostream &, Espressione & );
        friend Tartaruga & operator << ( Tartaruga &, Espressione & );
        friend istream & operator >> ( istream &, Espressione & );
        /// operatori di in/out put di una espressione aritmetica

        ///Espressione operator + ( Espressione & ); /// somma di due espressioni
        ///...
        /// altri operatori ...
        void Vedi(char *);

 protected:
      // int ID; static cntID;
      void VisitaSimmRic( Nodo* , ostream & , int parentesi);
      void costruisci( const char * E );
      ///static char* F_SIMB[];
      /// stringhe delle funzioni possibili di Espressione
      /// ( si possono aggiungere funzioni create dall'utente )

      ///static double (* FUNC[]) (double);
      /// Tabella di puntatori a funzioni di libreria o dell'utente

      double VAL[128];  /// Tabella per i valori di costanti
      int dimVAL;
      double valX;

      enum { ZERO = -1, UNO = -2 };  /// prime due posizioni per la  VAL

      //--------------------------------------------------------------
      Nodo * FaiAlberoEspressione( char * & );
      Nodo * FaiAlberoTermine( char * & );
      Nodo * FaiAlberoFattore( char * & );

      double ValutaR( Nodo * );
      Nodo * DerivaR(Nodo * );

      void Semplifica( );
      int SemplificaRic( Nodo * & T );

      void CoefficentiSinistra( Nodo * & T );

      void Errore(const char * Mess, const char * pE);
      int IsFunction(Nodo *);

 }; /*Espressione*/

#endif
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   BOTTONI %%%%%%%%%%%%
class Bottone: protected Grafica
{ public:

Bottone( float Xi, float Yi, ColoreRGB Colore, char *Frase=0, float L=0, float A=0);
/// Il parametro "Frase" e` una stringa che viene riportata all'interno del
/// Bottone; ogni \n corrisponde ad una frase associata con lo stato del bott.
/// Ricordo che la scritta si puo` colorare inserendo all'inizio di una nuova riga
/// i caratteri: @Cnn

  ~Bottone();

  int Stato() const; ///osservazione dello stato del bottone: 0, N
  void Stato(unsigned int); ///impone nuovo stato del bottone: 0, N

  int PremutoeRilasciato();
  /// indica se il bottone su schermo e` stato premuto e rilasciato
  /// e con quale  pulsante del mouse.
  /// Questo test provoca l'impressione visiva di un pulsante premuto
  /// quando il tasto del mouse rimane schiacciato e il bottone cambia di stato.

  int Premuto();
  /// indica se il bottone su schermo e` stato premuto e con quale
  /// pulsante del mouse.

  bool MouseSopra();
  /// indica se il mouse e` sopra il bottone (1)

  static void Click();
  static void NoClick();

  protected:

  Bottone(const Bottone &); /// Copy Constructor

  int ID, stato,
  Nstati, NoBistabile,
  Tx, Ty,
  Xi,Yi,Xs,Ys;

  ColoreRGB Sfondo, Segno, ColoreChiaro;

  static bool MouseDentroA, suono;
  static int cntID;

  char * StrFrase, *S;
  char ** Parola; /// vettore di puntatori a parole relative a ciascun stato
		  /// che puntano alla StrFrase in corrispond. a ciascun '/n'
  void DisegnaBottoneOriginale(int=0);
  void DisegnaBottoneCambiato();

  int * pFondo;

};//Bottone

#endif
//******************************** fine include EASY_C5.H *******************

