/** **************************************************************
* @brief Prova dell'installazione della grafica della Tartaruga
* @author Renato Conte - ITIS "C.ZUCCANTE" - Mestre - VENEZIA
* @version Tarta_CodeBlocks 16.01
* @date settembre 2017
                                          libgdi32.a
* ***************************************************************/

#include <Tarta_CodeBlocks.h>

/** ------------------------------------------------------------
 @brief breve collaudo main e libreria libTarta_CodeBlocks
 @param nessuno
 @return stato d'errore nullo al sistema
-------------------------------------------------------------- */
int main()
{   Tartaruga T;///< "nasce" l'oggetto Tartaruga
    int R=100;
    int L= 150;

for(int i=0; i<100; i++)
  {    cout << i << endl;
      T.VaiAvanti(L);
        T.CambiaColorePennello(ColoreRGB::Random());
        T.Cerchio(R--); ///< fai un cerchio

  	    T.VaiAvanti(-L);
  	    T.GiraSinistra(123);

   }//for


 WaitESC("fine programma");
return 0;
}//*fine-main
