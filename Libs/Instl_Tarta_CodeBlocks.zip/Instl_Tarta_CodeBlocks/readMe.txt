Questa e' una cartella contenente un file d'esempio 
per poter lavorare con la libreria della Tartaruga.


Contiente anche una cartella "FileDaCopiareInMinGW",

che contiene tre file da copiare nella cartella di 
installazione di CodeBlocks, 
in particolare in MinGW.


Piu' precisamente copiare:

"Tarta_CodeBlocks.h" nella cartella "MinGW\include"


"libgdi.a" e "libTarta_CodeBlocks.a" 
nella cartella "MinGW\lib"



Attenzione che il progetto deve aggiungere nelle
"Project Build options" \ "linker Setting"

nella finestra "link libraries"
le seguenti due righe, nell'ordine indicato:


libTarta_CodeBlocks.a

libgdi32.a




buon lavoro


---
Renato

2017